--!mgscr-begin
--title,蛇行 (Meandering)
--variable,beat,length,長さ (小節数),0,1,4
--variable,pow2track,division,分割数,1,8,7
--variable,track,marginLeft,横位置 1,0,15,0
--variable,track,marginRight,横位置 2,0,15,4
--variable,track,width,SLIDE 幅,1,16,2
--variable,track,skew,傾き,0,15,6
--variable,check,flipH,左右反転,0
--!mgscr-end

function main()
  local leftOffset = 0
  local resolution = math.max(length / division, 1)
  local steps = length / resolution
  local x, tick = 0, 0
  
  for i = 0, steps do
    if i % 4 == 0 then
      leftOffset = math.floor(i / steps * skew)
    end
    
    tick = i * resolution
    if i >= steps then
      tick = length
    end
    
    x = leftOffset + ((math.floor((i - 1) / 2 + 0.5) % 2 == 0) and marginLeft or (marginRight))
    
    if flipH == 1 then
      x = 16 - x - width
    end
    
    table.insert(g_Elements, {
      x = x,
      width = width,
      tick = tick
    })
  end
end
