--!mgscr-begin
--title,蛇腹 (Zigzag)
--variable,beat,length,長さ (小節数),0,1,4
--variable,pow2track,division,分割数,1,8,4
--variable,track,beginWidth,始点幅,1,16,4
--variable,track,stepX1,横位置 1,-15,15,1
--variable,track,stepWidth1,幅 1,1,16,4
--variable,track,stepX2,横位置 2,-15,15,-1
--variable,track,stepWidth2,幅 2,1,16,4
--!mgscr-end

function main()
  local x, tick = 0, 0
  local resolution = math.max(length / division, 1)
  local steps = length / resolution

  table.insert(g_Elements, {
    x = 0,
    width = beginWidth,
    tick = 0
  })

  for i = 1, steps - 1 do
    tick = i * resolution
    if i % 2 == 0 then
      table.insert(g_Elements, {
        x = stepX2,
        width = stepWidth2,
        tick = tick
      })
    else
      table.insert(g_Elements, {
        x = stepX1,
        width = stepWidth1,
        tick = tick
      })
    end
  end

  table.insert(g_Elements, {
    x = 0,
    width = beginWidth,
    tick = length
  })

  for i = 1, #g_Elements do
    g_Elements[i].x = g_Elements[i].x + math.max(-math.min(stepX1, stepX2), 0)
  end
end
