--!mgscr-begin
--title,曲線 (Curve)
--variable,beat,length,長さ (小節数),0,1,8
--variable,track,width,SLIDE 幅,1,16,4
--variable,track,xMove,終点横位置,0,15,12
--variable,track,xOffset,横移動,0,16,0
--variable,check,symmetryH,左右線対称,0
--variable,check,symmetryV,上下線対称,0
--variable,check,flipH,左右反転,0
--variable,check,flipV,上下反転,0
--!mgscr-end

slidePoints = {

  {0, 0},
  {240, 0},
  {480, 0},
  {600, 1},
  {720, 1},
  {960, 0},
  {1020, 1},
  {1140, 2},
  {1200, 2},
  {1440, 0},
  {1470, 1},
  {1520, 2},
  {1620, 3},
  {1680, 3},
  {1920, 0},
  {1940, 1},
  {1972, 2},
  {2020, 3},
  {2100, 4},
  {2160, 4},
  {2400, 0},
  {2415, 1},
  {2440, 2},
  {2472, 3},
  {2520, 4},
  {2600, 5},
  {2640, 5},
  {2880, 0},
  {2895, 1},
  {2912, 2},
  {2936, 3},
  {2964, 4},
  {3008, 5},
  {3090, 6},
  {3120, 6},
  {3360, 0},
  {3372, 1},
  {3388, 2},
  {3408, 3},
  {3432, 4},
  {3464, 5},
  {3504, 6},
  {3570, 7},
  {3600, 7},
  {3840, 0},
  {3860, 2},
  {3888, 4},
  {3908, 5},
  {3936, 6},
  {3976, 7},
  {4050, 8},
  {4080, 8},
  {4320, 0},
  {4332, 2},
  {4352, 4},
  {4368, 5},
  {4388, 6},
  {4416, 7},
  {4456, 8},
  {4530, 9},
  {4560, 9},
  {4800, 0},
  {4812, 2},
  {4832, 4},
  {4864, 6},
  {4884, 7},
  {4908, 8},
  {4948, 9},
  {5010, 10},
  {5040, 10},
  {5280, 0},
  {5292, 2},
  {5312, 4},
  {5324, 5},
  {5356, 7},
  {5376, 8},
  {5400, 9},
  {5432, 10},
  {5490, 11},
  {5520, 11},
  {5760, 0},
  {5776, 3},
  {5792, 5},
  {5804, 6},
  {5816, 7},
  {5832, 8},
  {5852, 9},
  {5876, 10},
  {5910, 11},
  {5970, 12},
  {6000, 12},
  {6240, 0},
  {6248, 2},
  {6268, 5},
  {6288, 7},
  {6300, 8},
  {6316, 9},
  {6332, 10},
  {6356, 11},
  {6392, 12},
  {6450, 13},
  {6480, 13},
  {6720, 0},
  {6728, 2},
  {6748, 5},
  {6756, 6},
  {6776, 8},
  {6788, 9},
  {6804, 10},
  {6824, 11},
  {6852, 12},
  {6884, 13},
  {6930, 14},
  {6960, 14},
  {7200, 0},
  {7204, 2},
  {7208, 3},
  {7220, 5},
  {7236, 7},
  {7248, 8},
  {7260, 9},
  {7276, 10},
  {7296, 11},
  {7340, 13},
  {7372, 14},
  {7420, 15},
  {7440, 15}
}

-- 移動量から SLIDE の素を得る
function getSlideBaseElms(x)
  local elm = {}
  local tickBegin = x * 480
  local tickEnd = x * 480 + 240
  
  for i = 1, #slidePoints do
    if slidePoints[i][1] >= tickBegin and slidePoints[i][1] <= tickEnd then
      table.insert(elm, {
        tick = slidePoints[i][1] - tickBegin,
        x = slidePoints[i][2]
      })
    end
  end

  return elm
end

function main()
  local baseElm = getSlideBaseElms(xMove)
  local tickLength = 240
  
  for i = 1, #baseElm do
    local w = width
    local x = baseElm[i].x + xOffset
    w = math.min(w, 16 - x)
    table.insert(g_Elements, {
      x = x,
      width = w,
      tick = baseElm[i].tick
    })
  end

  if flipH == 1 then -- 左右反転
    for i = 1, #g_Elements do
      g_Elements[i].x = 16 - g_Elements[i].x - g_Elements[i].width
    end
  end

  if flipV == 1 then -- 上下反転
    for i = 1, #g_Elements do
      g_Elements[i].tick = tickLength - g_Elements[i].tick
    end
    table.sort(g_Elements, function(a, b)
      return (a.tick < b.tick)
    end)
  end

  if symmetryV == 1 then -- 線対称
    for i = #g_Elements - 1, 1, -1 do
      table.insert(g_Elements, {
        x = g_Elements[i].x,
        width = g_Elements[i].width,
        tick = tickLength * 2 - g_Elements[i].tick
      })
    end
    tickLength = 480
  end

  if symmetryH == 1 then -- 線対称
    for i = 1, #g_Elements do
      if (g_Elements[i].x >= 7) then
        g_Elements[i].x = 16 - g_Elements[i].x - math.max(g_Elements[i].width, 2)
      end
      g_Elements[i].width = math.max(16 - g_Elements[i].x * 2, math.min(g_Elements[i].x + g_Elements[i].width, 8) - g_Elements[i].x)
    end
  end

  -- scale tick
  local scaleTick = length / tickLength
  for i = 1, #g_Elements do
    g_Elements[i].tick = g_Elements[i].tick * scaleTick
  end
end
