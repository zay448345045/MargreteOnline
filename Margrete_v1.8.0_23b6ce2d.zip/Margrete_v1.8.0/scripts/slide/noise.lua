--!mgscr-begin
--title,雑音 (Noise)
--variable,beat,length,長さ (小節数),0,1,4
--variable,pow2track,division,分割数,1,8,7
--variable,track,w,SLIDE 幅,1,8,2
--variable,track,discardProb,破棄する確率,0,10,0
--variable,check,zigzag,綺麗なジグザグ,1
--!mgscr-end

math.randomseed(os.time())

function main()
  local lastX = 16
  local x, tick = 0, 0
  local resolution = math.max(length / division, 1)
  local steps = length / resolution
  local discardProbReal = discardProb / 10

  for i = 0, steps do
    if i == 0 or i >= steps or math.random() >= discardProbReal then
      if zigzag == 1 then
        x = math.random(13 - w)
        if x >= 5 - w / 2 then
          x = x + 3
        end
        if (lastX < 8 and x < 8) or (lastX >= 8 and x >= 8) then
          x = 16 - x - w
        end
      else
        x = math.random(16 - w)
      end
      
      tick = i * resolution
      if i >= steps then
        tick = length
      end
      
      table.insert(g_Elements, {
        x = x,
        width = w,
        tick = tick
      })
      
      lastX = x
    end
  end
end
